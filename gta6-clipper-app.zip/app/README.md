# GTA 6 Clipper

Paste a YouTube link, get 9:16 clips of the loudest / most exciting moments, with captions.

## Run on a computer
1. Install Python 3.10+ and ffmpeg.
2. `pip install -r requirements.txt`
3. `uvicorn server:app --host 0.0.0.0 --port 8000`
4. Open http://localhost:8000 (on your phone: http://<computer-ip>:8000 on the same wifi).

## Put it online for your phone
Upload this folder to GitHub, then create a "Web Service" from it on Render, Railway or Fly.io.
They detect the Dockerfile and give you a link. Open it on your phone and use
"Add to Home screen" to install it like an app.

## Notes
- Live streams: records the first 10 minutes (change LIVE_SECONDS in clipper.py).
- Faster: remove `faster-whisper` from requirements.txt (no captions, no hype words).
- Only clip videos you have permission to use.
- Clips are saved in /output; delete old folders now and then.
- YouTube may block downloads from some server IPs. Update yt-dlp (`pip install -U yt-dlp`) if it fails.
